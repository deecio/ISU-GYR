# ISU-GYR
<p>Group Number: DEC1612</p>
<p>Project Title: Green Your Residence</p>
<p>Team Leader + Key Concept Holder: Brianna Gerads<p>
<p>Communication Leader: Guan Keng Lim<p>
<p>Webmaster: Daniel Cain<p>
Senior Design Project for the Iowa State University Department of Sustainability, with the goal of presenting important information about Green Living in new and engaging ways.
